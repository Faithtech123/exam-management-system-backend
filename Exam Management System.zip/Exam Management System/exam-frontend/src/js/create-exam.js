import { createExam } from "./api.js";
import { requireRole } from "./auth.js";

if (!requireRole(["admin"])) throw new Error("unauthorized");

let questionCount = 0;

function addQuestionBlock() {
  const id = questionCount++;
  const container = document.getElementById("questions");
  const block = document.createElement("div");
  block.className = "border rounded-lg p-4 space-y-2";
  block.dataset.qid = id;
  block.innerHTML = `
    <input placeholder="Question text" class="q-text w-full border rounded px-2 py-1" required>
    <div class="grid grid-cols-2 gap-2">
      <input placeholder="Option A" class="q-opt w-full border rounded px-2 py-1" required>
      <input placeholder="Option B" class="q-opt w-full border rounded px-2 py-1" required>
      <input placeholder="Option C" class="q-opt w-full border rounded px-2 py-1" required>
      <input placeholder="Option D" class="q-opt w-full border rounded px-2 py-1" required>
    </div>
    <select class="q-correct border rounded px-2 py-1">
      <option value="0">Correct: A</option>
      <option value="1">Correct: B</option>
      <option value="2">Correct: C</option>
      <option value="3">Correct: D</option>
    </select>
    <button type="button" class="remove-q text-red-500 text-sm">Remove</button>
  `;
  block.querySelector(".remove-q").addEventListener("click", () => block.remove());
  container.appendChild(block);
}

document.getElementById("add-question").addEventListener("click", addQuestionBlock);
addQuestionBlock(); // start with one question by default

document.getElementById("create-exam-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const msgEl = document.getElementById("msg");

  const questionBlocks = document.querySelectorAll("#questions > div");
  const questions = Array.from(questionBlocks).map(block => ({
    text: block.querySelector(".q-text").value,
    options: Array.from(block.querySelectorAll(".q-opt")).map(i => i.value),
    correctIndex: parseInt(block.querySelector(".q-correct").value),
  }));

  const exam = {
    title: document.getElementById("title").value,
    durationMinutes: parseInt(document.getElementById("duration").value),
    questions,
  };

  try {
    await createExam(exam);
    msgEl.textContent = "Exam created!";
    msgEl.className = "text-green-600 text-sm";
    setTimeout(() => window.location.href = "admin-dashboard.html", 1000);
  } catch (err) {
    msgEl.textContent = err.message;
    msgEl.className = "text-red-500 text-sm";
  }
});
