import { fetchAllExams } from "./api.js";
import { requireRole } from "./auth.js";

if (requireRole(["student"])) renderExams();

async function renderExams() {
  const container = document.getElementById("exam-list");
  const exams = await fetchAllExams();
  container.innerHTML = exams.map(e => `
    <div class="border rounded-lg p-4 flex justify-between items-center">
      <div>
        <h2 class="font-semibold">${e.title}</h2>
        <p class="text-sm text-gray-500">${e.questions.length} questions • ${e.durationMinutes} min</p>
      </div>
      <a href="take-exam.html?id=${e.id}" class="bg-black text-white px-3 py-1 rounded text-sm">Start</a>
    </div>
  `).join("");
}