import { login } from "./api.js";
	
document.getElementById("login-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;
  const errorEl = document.getElementById("error");

  try {
    const result = await login(email, password);
    window.location.href = result.user.role === "admin" ? "admin-dashboard.html" : "student-dashboard.html";
  } catch (err) {
    errorEl.textContent = err.message;
  }
});
