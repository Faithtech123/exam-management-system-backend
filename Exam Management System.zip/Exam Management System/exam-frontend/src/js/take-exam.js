import { fetchExamToTake, submitExam } from "./api.js";
import { requireRole } from "./auth.js";

if (!requireRole(["student"])) throw new Error("unauthorized");

const params = new URLSearchParams(window.location.search);
const examId = params.get("id");
let timerInterval;
let secondsLeft;

async function loadExam() {
  const exam = await fetchExamToTake(examId);
  document.getElementById("exam-title").textContent = exam.title;

  const form = document.getElementById("exam-form");
  form.innerHTML = exam.questions.map((q, i) => `
    <div class="border rounded-lg p-4">
      <p class="font-medium mb-2">${i + 1}. ${q.text}</p>
      ${q.options.map((opt, idx) => `
        <label class="block text-sm mb-1">
          <input type="radio" name="q${i}" value="${idx}" class="mr-2">${opt}
        </label>
      `).join("")}
    </div>
  `).join("");

  secondsLeft = exam.durationMinutes * 60;
  startTimer();

  document.getElementById("submit-btn").addEventListener("click", () => submit(exam));
}

function startTimer() {
  const timerEl = document.getElementById("timer");
  timerInterval = setInterval(() => {
    secondsLeft--;
    const mins = Math.floor(secondsLeft / 60).toString().padStart(2, "0");
    const secs = (secondsLeft % 60).toString().padStart(2, "0");
    timerEl.textContent = `${mins}:${secs}`;

    if (secondsLeft <= 0) {
      clearInterval(timerInterval);
      alert("Time's up! Submitting automatically.");
      submit();
    }
  }, 1000);
}

async function submit() {
  clearInterval(timerInterval);
  const form = document.getElementById("exam-form");
  const formData = new FormData(form);
  const answers = {};
  for (const [key, value] of formData.entries()) {
    answers[key.replace("q", "")] = parseInt(value);
  }

  try {
    const result = await submitExam(examId, answers);
    window.location.href = `results.html?id=${result.resultId}`;
  } catch (err) {
    alert(err.message);
  }
}

loadExam();
