import { register } from "./api.js";

document.getElementById("register-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const data = {
    name: document.getElementById("name").value,
    email: document.getElementById("email").value,
    password: document.getElementById("password").value,
    role: document.getElementById("role").value,
  };
  const errorEl = document.getElementById("error");

  try {
    await register(data);
    window.location.href = "login.html";
  } catch (err) {
    errorEl.textContent = err.message;
  }
});
