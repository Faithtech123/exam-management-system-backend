import { fetchMyResults } from "./api.js";
import { requireRole } from "./auth.js";

if (requireRole(["student"])) renderResults();

async function renderResults() {
  const container = document.getElementById("results");
  const results = await fetchMyResults();
  container.innerHTML = results.map(r => `
    <div class="border rounded-lg p-4">
      <p class="font-semibold">${r.examTitle}</p>
      <p class="text-sm text-gray-500">Score: ${r.score}/${r.total}</p>
    </div>
  `).join("");
}
