const API_BASE ="https://exam-management-system.com"; // change to match whichever backend you build

export async function authFetch(url, options = {}) {
  const token = localStorage.getItem("token");
  return fetch(url, {
    ...options,
    headers: { ...options.headers, Authorization: `Bearer ${token}` },
  });
}

// --- Auth ---
export async function register(data) {
  const res = await fetch(`${API_BASE}/auth/register`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  const result = await res.json();
  if (!res.ok) throw new Error(result.error || "Registration failed");
  return result;
}

export async function login(email, password) {
  const res = await fetch(`${API_BASE}/auth/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email, password }),
  });
  const result = await res.json();
  if (!res.ok) throw new Error(result.error || "Login failed");
  localStorage.setItem("token", result.token);
  localStorage.setItem("role", result.user.role);
  return result;
}

// --- Exams (admin) ---
export async function createExam(exam) {
  const res = await authFetch(`${API_BASE}/exams`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(exam),
  });
  const result = await res.json();
  if (!res.ok) throw new Error(result.error || "Failed to create exam");
  return result;
}

export async function fetchAllExams() {
  const res = await authFetch(`${API_BASE}/exams`);
  if (!res.ok) throw new Error("Failed to fetch exams");
  return res.json();
}

// --- Exams (student) ---
export async function fetchExamToTake(examId) {
  // expected to return exam WITHOUT correct answers included
  const res = await authFetch(`${API_BASE}/exams/${examId}/take`);
  if (!res.ok) throw new Error("Failed to load exam");
  return res.json();
}

export async function submitExam(examId, answers) {
  const res = await authFetch(`${API_BASE}/exams/${examId}/submit`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ answers }),
  });
  const result = await res.json();
  if (!res.ok) throw new Error(result.error || "Failed to submit exam");
  return result;
}

// --- Results ---
export async function fetchMyResults() {
  const res = await authFetch(`${API_BASE}/results`);
  if (!res.ok) throw new Error("Failed to fetch results");
  return res.json();
}

export async function fetchResultDetail(resultId) {
  const res = await authFetch(`${API_BASE}/results/${resultId}`);
  if (!res.ok) throw new Error("Failed to fetch result");
  return res.json();
}
