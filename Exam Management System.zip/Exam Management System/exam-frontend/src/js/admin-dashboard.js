import { fetchAllExams } from "./api.js";
import { requireRole } from "./auth.js";

if (requireRole(["admin"])) {
  renderExams();
}

async function renderExams() {
  const container = document.getElementById("exam-list");
  try {
    const exams = await fetchAllExams();
    container.innerHTML = exams.map(e => `
      <div class="border rounded-lg p-4">
        <h2 class="font-semibold">${e.title}</h2>
        <p class="text-sm text-gray-500">${e.questions.length} questions • ${e.durationMinutes} min</p>
      </div>
    `).join("");
  } catch (err) {
    container.innerHTML = `<p class="text-red-500">Could not load exams.</p>`;
  }
}
