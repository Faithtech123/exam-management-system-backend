export function isLoggedIn() {
  return !!localStorage.getItem("token");
}

export function getRole() {
  return localStorage.getItem("role");
}

export function logout() {
  localStorage.removeItem("token");
  localStorage.removeItem("role");
  window.location.href = "login.html";
}

export function requireRole(allowedRoles) {
  if (!isLoggedIn()) {
    window.location.href = "login.html";
    return false;
  }
  if (!allowedRoles.includes(getRole())) {
    alert("You don't have access to this page");
    window.location.href = "login.html";
    return false;
  }
  return true;
}
